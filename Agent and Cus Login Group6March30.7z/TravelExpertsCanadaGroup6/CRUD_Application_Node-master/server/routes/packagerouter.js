const express = require('express');
const route = express.Router()

const services = require('../services/packagerender');
const controller = require('../controller/packagecontroller');

/**
 *  @description Root Route
 *  @method GET /
 */
route.get('/packageindex', services.homeRoutes);

/**
 *  @description add packages
 *  @method GET /add-package
 */
route.get('/add-package', services.add_package)

/**
 *  @description for update package
 *  @method GET /update-package
 */
route.get('/update-package', services.update_package)


// API
route.post('/api/packages', controller.create);
route.get('/api/packages', controller.find);
route.put('/api/packages/:id', controller.update);
route.delete('/api/packages/:id', controller.delete);


module.exports = route