const mongoose = require('mongoose');

var schema = new mongoose.Schema({
    firstname : {
        type : String,
   
    },
    lastname : {
        type : String,
     
    },
    email : {
        type: String,
    
        unique: true
    },
    tel1 : {
        type: String,
    },
    tel2 : {
        type: String,
    },    
    dob : {
        type: String,
    },
    status : String,
})

var Userdb = mongoose.model('userdb', schema);

module.exports = Userdb;