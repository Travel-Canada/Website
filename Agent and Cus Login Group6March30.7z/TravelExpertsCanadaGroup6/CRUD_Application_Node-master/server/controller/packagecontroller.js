var Packagedb = require('../model/packagemodel');

// create and save new package
exports.create = (req,res)=>{
    // validate request
    if(!req.body){
        res.status(400).send({ message : "Content can not be emtpy!"});
        return;
    }

    // new package
    const package = new Packagedb({
    title: req.body.title,
    description: req.body.description,
    price: req.body.price,
    status : req.body.status
    })

    // save package in the database
    package
        .save(package)
        .then(data => {
            //res.send(data)
            res.redirect('/add-package');
        })
        .catch(err =>{
            res.status(500).send({
                message : err.message || "Some error occurred while creating a create operation"
            });
        });

}

// retrieve and return all packages/ retrive and return a single package
exports.find = (req, res)=>{

    if(req.query.id){
        const id = req.query.id;

        Packagedb.findById(id)
            .then(data =>{
                if(!data){
                    res.status(404).send({ message : "Not found package with id "+ id})
                }else{
                    res.send(data)
                }
            })
            .catch(err =>{
                res.status(500).send({ message: "Erro retrieving package with id " + id})
            })

    }else{
        Packagedb.find()
            .then(package => {
                res.send(package)
            })
            .catch(err => {
                res.status(500).send({ message : err.message || "Error Occurred while retriving package information" })
            })
    }

    
}

// Update a new idetified package by package id
exports.update = (req, res)=>{
    if(!req.body){
        return res
            .status(400)
            .send({ message : "Data to update can not be empty"})
    }

    const id = req.params.id;
    Packagedb.findByIdAndUpdate(id, req.body, { useFindAndModify: false})
        .then(data => {
            if(!data){
                res.status(404).send({ message : `Cannot Update package with ${id}. Maybe package not found!`})
            }else{
                res.send(data)
            }
        })
        .catch(err =>{
            res.status(500).send({ message : "Error Update package information"})
        })
}

// Delete a package with specified package id in the request
exports.delete = (req, res)=>{
    const id = req.params.id;

    Packagedb.findByIdAndDelete(id)
        .then(data => {
            if(!data){
                res.status(404).send({ message : `Cannot Delete with id ${id}. Maybe id is wrong`})
            }else{
                res.send({
                    message : "package was deleted successfully!"
                })
            }
        })
        .catch(err =>{
            res.status(500).send({
                message: "Could not delete package with id=" + id
            });
        });
}