const mongoose = require('mongoose');

var Agentschema = new mongoose.Schema({
    firstname : {
        type : String,
    
    },
    lastname : {
        type : String,
        
    },
    email : {
        type: String,
       
        unique: true
    },
    tel1 : {
        type: String,
    },
    tel2 : {
        type: String,
    },    
    dob : {
        type: String,
    },
    status : String
   
})

var Agentdb = mongoose.model('agentdb', Agentschema);

module.exports = Agentdb;