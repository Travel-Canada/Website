const mongoose = require('mongoose');

var Packageschema = new mongoose.Schema({
    name : {
        type : String,
        
    },
    title : {
        type: String,
        
        
    },
    description : {
        type: String,
        
        
    }, price : {
        type: Number,
        
    
    },status : String,

})

var Packagedb = mongoose.model('packagedb', Packageschema);

module.exports = Packagedb;