const express = require('express');
const route = express.Router()

const services = require('../services/agentrender');
const controller = require('../controller/agentcontroller');

/**
 *  @description Root Route
 *  @method GET /
 */
route.get('/agentindex', services.homeRoutes);

/**
 *  @description add agents
 *  @method GET /add-agent
 */
route.get('/add-agent', services.add_agent)

/**
 *  @description for update agent
 *  @method GET /update-agent
 */
route.get('/update-agent', services.update_agent)


// API
route.post('/api/agents', controller.create);
route.get('/api/agents', controller.find);
route.put('/api/agents/:id', controller.update);
route.delete('/api/agents/:id', controller.delete);


module.exports = route