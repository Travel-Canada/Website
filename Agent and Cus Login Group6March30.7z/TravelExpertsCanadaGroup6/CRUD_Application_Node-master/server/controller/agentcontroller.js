var Agentdb = require('../model/agentmodel');

// create and save new agent
exports.create = (req,res)=>{
    // validate request
    if(!req.body){
        res.status(400).send({ message : "Content can not be emtpy!"});
        return;
    }

    // new agent
    const agent = new Agentdb({
        firstname : req.body.firstname,
        lastname : req.body.lastname,
        email: req.body.email,
        tel1 : req.body.tel1,
        tel2 : req.body.tel2,
        dob : req.body.dob,
        status : req.body.status

        
        
    })

    // save agent in the database
    agent
        .save(agent)
        .then(data => {
            //res.send(data)
            res.redirect('/add-agent');
        })
        .catch(err =>{
            res.status(500).send({
                message : err.message || "Some error occurred while creating a create operation"
            });
        });

}

// retrieve and return all agents/ retrive and return a single agent
exports.find = (req, res)=>{

    if(req.query.id){
        const id = req.query.id;

        Agentdb.findById(id)
            .then(data =>{
                if(!data){
                    res.status(404).send({ message : "Not found agent with id "+ id})
                }else{
                    res.send(data)
                }
            })
            .catch(err =>{
                res.status(500).send({ message: "Erro retrieving agent with id " + id})
            })

    }else{
        Agentdb.find()
            .then(agent => {
                res.send(agent)
            })
            .catch(err => {
                res.status(500).send({ message : err.message || "Error Occurred while retriving agent information" })
            })
    }

    
}

// Update a new idetified agent by agent id
exports.update = (req, res)=>{
    if(!req.body){
        return res
            .status(400)
            .send({ message : "Data to update can not be empty"})
    }

    const id = req.params.id;
    Agentdb.findByIdAndUpdate(id, req.body, { useFindAndModify: false})
        .then(data => {
            if(!data){
                res.status(404).send({ message : `Cannot Update agent with ${id}. Maybe agent not found!`})
            }else{
                res.send(data)
            }
        })
        .catch(err =>{
            res.status(500).send({ message : "Error Update agent information"})
        })
}

// Delete a agent with specified agent id in the request
exports.delete = (req, res)=>{
    const id = req.params.id;

    Agentdb.findByIdAndDelete(id)
        .then(data => {
            if(!data){
                res.status(404).send({ message : `Cannot Delete with id ${id}. Maybe id is wrong`})
            }else{
                res.send({
                    message : "agent was deleted successfully!"
                })
            }
        })
        .catch(err =>{
            res.status(500).send({
                message: "Could not delete agent with id=" + id
            });
        });
}