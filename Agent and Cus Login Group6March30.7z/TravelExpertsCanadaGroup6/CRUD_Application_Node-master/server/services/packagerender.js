const axios = require('axios');


exports.homeRoutes = (req, res) => {
    // Make a get request to /api/packages
    axios.get('http://localhost:3000/api/packages')
        .then(function(response){
            res.render('packageindex', { packages : response.data });
        })
        .catch(err =>{
            res.send(err);
        })

    
}

exports.add_package = (req, res) =>{
    res.render('add_package');
}

exports.update_package = (req, res) =>{
    axios.get('http://localhost:3000/api/packages', { params : { id : req.query.id }})
        .then(function(packagedata){
            res.render("update_package", { package : packagedata.data})
        })
        .catch(err =>{
            res.send(err);
        })
}