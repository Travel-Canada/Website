const axios = require('axios');


exports.homeRoutes = (req, res) => {
    // Make a get request to /api/agents
    axios.get('http://localhost:3000/api/agents')
        .then(function(response){
            res.render('agentindex', { agents : response.data });
        })
        .catch(err =>{
            res.send(err);
        })

    
}

exports.add_agent = (req, res) =>{
    res.render('add_agent');
}

exports.update_agent = (req, res) =>{
    axios.get('http://localhost:3000/api/agents', { params : { id : req.query.id }})
        .then(function(agentdata){
            res.render("update_agent", { agent : agentdata.data})
        })
        .catch(err =>{
            res.send(err);
        })
}